import json
config ='''{
    "agent_names":["Smriti","Ram","Sita","Pratik","Manisha"], 
    "keywords":{
        "cafe":"The cafe is open daily from 8AM to 9PM, if you want you can go", 
        "library":"Library open from 8AM to 5PM, if you like you can go", 
        "sports":"The ECA ground is open till 5PM, if you want you can go play with your friends there", 
        "parking":"Parking is free for student, if you have bike you can park"
    }, 
    "responses":[
        "That's interesting!",
        "Can you tell me more?"
    ]
}'''
data = json.loads(config)
def random(input_str, list_length):
    return len(input_str) % list_length
def chat():
    user_name=input("Welcome to Poppleton University! Enter your name: ")
    agent_name=data["agent_names"][random(user_name, len(data["agent_names"]))]
    print(f"Hi {user_name}, nice! My name is {agent_name}, and I'll be assisting you.")
    while True:
        user=input("You can ask me anything or bye: ")
        if user in {"bye"}:
            print(f"Goodbye, {user_name}! Have a great day!")
            break
        response=next((reply for keyword, reply in data["keywords"].items() if keyword in user), data["responses"][random(user, len(data["responses"]))])
        if random(user,2)==0:
            print(f"{response} {user_name}")
chat()

import sys 
def analyze_txt(times_file, detail_file):
    details, lap_times = {}, {}
    with open(detail_file,'r') as f:
        for line in f:
            car_number, driver_code, real_name, car_name = line.strip().split(',')
            details[driver_code] = {'car_number':car_number,'real_name':real_name,'car_name':car_name}
    with open(times_file,'r') as f:
        race_location=f.readline()
        print(f"\n Race Location : {race_location}")
        for line in f:
            driver_code, lap_time=line[:3], float(line[3:].strip())
            lap_times.setdefault(driver_code, []).append(lap_time)
    print(f"--------Race Data Analysis--------")
    print(f"Fastest and Average Time For Each Driver")
    fastest_driver, fastest_time, overall_time = None, float("inf"), []
    for driver, times in lap_times.items():
        time=min(times)
        overall_time.extend(times)
        if time<fastest_time:
            fastest_time,fastest_driver=time, driver
            avg=sum(times)/len(times) 
        info=details.get(driver,{})
        print(f"{info.get('car_number')} {driver},{info.get('real_name')},{info.get('car_name')} \nFastest: {time}, \nAvg: {avg:.2f}")
    overall_avg =  avg=sum(overall_time)/len(overall_time)
    print(f"\nAverage Time for all Drivers: {overall_avg:.2f}")
    print(f"\nFastest Driver code: {fastest_driver} : {fastest_time}")
    print(f"\nFastest Time in Descending order")
    for driver, times in sorted(lap_times.items(), key=lambda x:min(x[1]), reverse=True):
        info=details.get(driver,{})
        print(f"{info.get('car_number')} {driver},{info.get('real_name')},{info.get('car_name')}:{min(times)}")
if len(sys.argv) != 3:
    print("Usage:analyse_file.py<times_file><detail_file>")
    sys.exit(1)
analyze_txt(sys.argv[1],sys.argv[2])
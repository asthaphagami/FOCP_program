import sys
def file(file_name):
    try:
        with open(file_name, 'rb') as file1:
            line=file1.read()
        with open(file_name + '.bak','wb') as file2:
            file2.write(line)
        print(f"Backup of {file_name} created as {file_name}.bak")
    except FileNotFoundError:
        print(f"file {file_name} not found.")
    except Exception as e:
        print(f"ERROR:{e}")
if len(sys.argv)!=2:
    print("usage: python file.py <file_name>")
else:
    file(sys.argv[1])
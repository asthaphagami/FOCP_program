import sys
import requests
def check(url):
    try:
        response = requests.get(url)
        if response.content:
            print(f"{url} is working.")
        else:
            print(f"{url} returned an unsuccessful response.")
    except requests.exceptions.RequestException:
        print(f"Failed to reach {url}.")

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python url.py <url>")
    else:
        check(sys.argv[1])

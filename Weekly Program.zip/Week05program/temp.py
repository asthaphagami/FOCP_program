import sys
def temperature(temp):
    return max(temp), min(temp), sum(temp)/len(temp)
if len(sys.argv)<2:
    print("Usage:temp.py <temp1> <temp2> <temp3>")
else:
    temp=[float(arg) for arg in sys.argv[1:]]
    max_temp, min_temp, mean_temp=temperature(temp)
    print(f"maximum:{max_temp}, minimum:{min_temp}, mean:{mean_temp}")

import sys
def short():
    if len(sys.argv) > 1:
        print(f"Shortest argument: {min(sys.argv[1:], key=len)}")
    else:
        print("No argument")
short()

import sys
def count():
    print(f"Num of arguments: {len(sys.argv)-1}")
count()

import sys

def unix_diff(file1, file2):
    try:
        with open(file1,'r') as f1, open(file2,'r') as f2:
            line1 = f1.readlines()
            line2 = f2.readlines()
            if line1 == line2:
                print("Same Files")
            else:
                print("Different files")
    except FileNotFoundError as e:
        print(e)

if len(sys.argv) != 3:
    print("Usage: python diff.py <file1> <file2>")
else:
    unix_diff(sys.argv[1], sys.argv[2])

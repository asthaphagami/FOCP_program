import sys 
def Unix_wc(file_name):
    try:
        with open(file_name, 'r') as file:
            lines = file.readlines()
            print(f"Line: {len(lines)}")
            print(f"Character: {sum(len(line) for line in lines)}")
    except FileNotFoundError:
        print("ERROR")
if len(sys.argv) != 2:
    print("Usage: python wc.py <file_name>")
else:
    Unix_wc(sys.argv[1])

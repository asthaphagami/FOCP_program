import sys
def unix_nl(file_name):
    try:
        with open(file_name, 'r') as file:
            line= file.readlines()
            for i in range(len(line)):
                print(f"{i+1}{line[i]}", end='')
    except FileNotFoundError:
        print(f"ERROR")
if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python unix_nl.py <file_name>")
    else:
        unix_nl(sys.argv[1])
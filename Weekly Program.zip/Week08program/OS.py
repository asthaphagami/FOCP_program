import sys
def report_os():
    if sys.platform.startswith('linux'):
        print("Operating System: Linux")
    elif sys.platform.startswith('win'):
        print("Operating System: Windows")
    elif sys.platform.startswith('darwin'):
        print("Operating System: macOS")
    else:
        print("Operating System: Unknown")
report_os()

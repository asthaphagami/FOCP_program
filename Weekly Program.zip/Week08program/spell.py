import sys
def Unix_spell(file_name1, file_name2):
    try:
        with open(file_name2) as d_file:
            dict=set(d_file.read().split())
        with open(file_name1) as f_file:
            word=f_file.read().split()
            miss=[word for word in word if word.lower() not in dict]
            print("Misspelled words:", miss)
    except FileNotFoundError as e:
        print(f"error")
if len(sys.argv) != 3:
    print("Usage: python spell.py <file_name1> <file_name2>")
else:
    Unix_spell(sys.argv[1], sys.argv[2])

import sys
def unix_grep(pattern, file_name):
    try:
        with open(file_name, 'r') as file:
            lines = file.readlines()
            for line in lines:
                if pattern in line:
                    print(line, end='')
    except FileNotFoundError:
        print("ERROR")

if len(sys.argv) != 3:
    print("Usage: python grep.py <pattern> <file_name>")
else:
    unix_grep(sys.argv[1], sys.argv[2])
